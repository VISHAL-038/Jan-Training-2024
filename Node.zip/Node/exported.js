var a=require('./ex-imp')
var m=a.f1()
console.log("Add is:"+m);