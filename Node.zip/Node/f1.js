// console.log("how are you")
// node f1.js in terminal
// modules-local,built-in, third party
// npm init -y:for adding all dependencies we need before installing something
// install npm i nodemon-contain dependencies which we are using
var a=20;
var b=12.34;
var s="string";
console.log("integer value:"+a);
console.log("double value:"+b);
console.log("string value:"+s);