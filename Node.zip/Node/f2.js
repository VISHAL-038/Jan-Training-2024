var a=20;
var b=10;
var c=a/b;
var d=a+b;
var e=a-b;
console.log(a+"/"+b+"="+c);
console.log(a+"/"+b+"="+d);
console.log(a+"-"+b+"="+e);