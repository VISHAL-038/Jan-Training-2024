exports.f1=function()
{
    var q=20;
    var s=10;
    var t = q+s;

    console.log(q+"+"+s+"="+t);
    return t
}
// export this file in exported