// type-1
function f1()
{
    console.log("hello,how are u?");
}
f1()

// type-2
var f2= function()
{
    console.log("hello,hi");
}
f2()


const f3 = () => {
  console.log("hey");
}
f3()
